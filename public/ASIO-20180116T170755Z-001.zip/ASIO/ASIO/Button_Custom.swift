//
//  Button_Custom.swift
//  ASIO
//
//  Created by 岡本 祥治 on 2018/01/16.
//  Copyright © 2018年 岡本 祥治. All rights reserved.
//

import UIKit

import UIKit

@IBDesignable
class Button_Custom: UIButton {
    
    @IBInspectable var textColor: UIColor?
    
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            layer.cornerRadius = cornerRadius
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }

}
